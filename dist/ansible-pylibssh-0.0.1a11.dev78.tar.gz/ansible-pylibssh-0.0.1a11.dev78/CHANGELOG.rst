*********
Changelog
*********

0.0.1 Unreleased
================


0.0.1.dev1
==========

* Update package name to ansible-pylibssh to reflect the library support
  is limited to Ansible use case


0.0.1.dev0
==========

* Development release.
