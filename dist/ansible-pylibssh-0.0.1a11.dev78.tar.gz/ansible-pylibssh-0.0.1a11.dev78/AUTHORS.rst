
Contributors
============

Please see the following:

* `Contributors listing`_
* `Community working group members`_

.. _Contributors listing: https://github.com/ansible/pylibssh/graphs/contributors
.. _Community working group members: https://github.com/ansible/community/wiki/pylibssh


Credits
=======

Based on the good work of Jan Pazdziora (`@adelton`_).

.. _`@adelton`: https://github.com/adelton
